import { Component, EventEmitter, Output } from '@angular/core';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { FormsModule } from '@angular/forms';
import { User } from '../MyServices/user';
import { data } from '../../../data';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Inject } from '@angular/core';
@Component({
  selector: 'app-edit-dialog',
  standalone: true,
  imports: [    MatInputModule,
    MatButtonModule,
    MatDialogModule,
    FormsModule],
  templateUrl: './edit-dialog.component.html',
  styleUrl: './edit-dialog.component.scss'
})
export class EditDialogComponent {
  @Output() updateData: EventEmitter<any> = new EventEmitter<any>(); // Define an event emitter
  data : User[]= data
  constructor(
    public dialogRef: MatDialogRef<EditDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public dataItem: any
  ) {}

  onSave(): void {
    this.updateData.emit(this.dataItem);
    console.log(this.dataItem.name)
    console.log(this.dataItem.state)
    console.log(this.dataItem.phone)
    console.log(this.dataItem.email)
    this.dialogRef.close();
  }

  onCancel(): void {
    this.dialogRef.close();
  }

}
