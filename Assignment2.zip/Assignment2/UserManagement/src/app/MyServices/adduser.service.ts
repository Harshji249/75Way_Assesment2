import { Injectable } from '@angular/core';
import axios from 'axios';

@Injectable({
  providedIn: 'root'
})
export class AddUserService {
  public baseURL = 'http://localhost:3000/api/auth/adddata'

  constructor() { }
  authenticateUser: any = async(name: string, email: string, phone:string, state:string)=>{
    return await axios.post(this.baseURL ,{name:name, email:email,phone:phone,state:state})
  }
}
