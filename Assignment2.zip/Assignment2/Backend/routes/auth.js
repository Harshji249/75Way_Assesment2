const express = require("express");
const router = express.Router();
const User = require("../models/User");
const { body, validationResult } = require("express-validator");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Data = require("../models/Data");

const JWT_SECRET = "secretjwtstring";

router.post('/createuser', [
  body('name').isLength({ min: 3 }),
  body('email', 'Enter a valid Email').isEmail(),
  body('password').isLength({ min: 5 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() })
  }
  try {
      let checkUser = await User.findOne({ email: req.body.email });

      if (checkUser) {
          return res.status(400).json({ error: "User with this email already exists" })
      }
      const salt = await bcrypt.genSalt(10);
      const { name, email, password } = req.body;
      const secPass = await bcrypt.hash(password, salt)
      let user = new User({ name: name, email: email, password: secPass });
      user = await user.save()
      const data = {
          user: {
              id: user.id
          }
      }
      const authToken = jwt.sign(data, JWT_SECRET);
      res.json({ authToken })

  }
  catch (err) {
      console.error(err.message)
      res.status(500).send("Internal server error occured")
  }
})

//Authenticate a User using : POST "/api/auth/login"
router.post(
  "/login",
  [
    body("email", "Enter a valid Email").isEmail(),
    body("password", "Password cannot be blank").exists(),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const { email, password } = req.body;
    try {
      let user = await User.findOne({ email });
      if (!user) {
        return res
          .status(400)
          .json({ error: "Loggin with correct credentials" });
      }
      const passwordCompare = await bcrypt.compare(password, user.password);
      if (!passwordCompare) {
        return res
          .status(400)
          .json({ error: "Loggin with correct credentials" });
      }
      const data = {
        user: {
          id: user.id,
        },
      };
      const authToken = jwt.sign(data, JWT_SECRET);
      res.json({ authToken, user });
    } catch (err) {
      console.error(err.message);
      res.status(500).send("Internal server error occured");
    }
  }
);

router.post("/adddata", async (req, res) => {
  try {
    const { name, email, state, phone } = req.body;
    let data = new Data({
      name,
      email,
      state,
      phone,
    });
    data = await data.save();
    res.json({ data });
  } catch (err) {
    console.log(err);
  }
});

router.get("/getalldata", async (req, res) => {
  try {
    let findUser = await Data.find();
    if (findUser) {
      return res.status(200).json({ data: findUser });
    } else {
      return res.status(500).json({ error: "NOT FOUND ANY THING" });
    }
  } catch (err) {
    console.log(err);
  }
});

router.put("/updateuser/:id", async (req, res) => {
  const { name, state, phone, email } = req.body;
  console.log("Received update request:", {
    id: req.params.id,
    name,
    state,
    phone,
    email,
  });
  const newUser = {};
  if (name) {
    newUser.name = name;
  }
  if (state) {
    newUser.state = state;
  }
  if (phone) {
    newUser.phone = phone;
  }
  if (email) {
    newUser.email = email;
  }

  let user = await Data.findById(req.params.id);
  console.log("NOT OF USER UPPER LOG", user);
  if (!user) {
    res.status(404).send("Not Found");
  }
  user = await Data.findByIdAndUpdate(
    req.params.id,
    { $set: newUser },
    { new: true }
  );
  res.json({ user });
});

module.exports = router;
