import { Component } from '@angular/core';
import { NgxOtpInputConfig, NgxOtpInputModule } from 'ngx-otp-input';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { OtpverifyComponent } from '../otpverify/otpverify.component';
@Component({
  selector: 'app-otp',
  standalone: true,
  imports: [NgxOtpInputModule, RouterOutlet, RouterLink,OtpverifyComponent],
  templateUrl: './otp.component.html',
  styleUrl: './otp.component.scss',
})
export class OtpComponent {
  constructor(private router: Router) {}
  otpInputConfig: NgxOtpInputConfig = {
    otpLength: 4,
    autofocus: true,
    classList: {
      inputBox: 'my-super-box-class',
      input: 'my-sper-class',
      inputFilled: 'my-super-filled-class',
      inputDisabled: 'my-super-disable-class',
      inputError: 'my-super-error-class',
    },
  };

  handleOtpChange(value: string[]): void {
    console.log(value);
  }
  handleFillEvent(value: string): void {
    console.log(value);
    if (value != '1234') {
      console.log('wrong otp');
    } else {
      console.log('right otp');
      this.router.navigate(['home']); 
    }
  }
}
