import { Component, NgModule, OnInit } from '@angular/core';
import {
  FormsModule,
  Validators,
  FormBuilder,
  FormGroup,
} from '@angular/forms';
import {
  GridModule,
  AddEvent,
  GridDataResult,
  CellClickEvent,
  CellCloseEvent,
  SaveEvent,
  CancelEvent,
  GridComponent,
  RemoveEvent,
} from '@progress/kendo-angular-grid';
import {MatButtonModule} from '@angular/material/button';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { Observable } from 'rxjs';
import { State, process } from '@progress/kendo-data-query';
import { Keys } from '@progress/kendo-angular-common';
import { User } from '../../MyServices/user';
import { Product } from '../../MyServices/model';
import { EditService } from '../../MyServices/Edit/edit.service';
import { map } from 'rxjs/operators';
import { CommonModule } from '@angular/common';
import {
  HttpClient,
  HttpClientJsonpModule,
  HttpClientModule,
} from '@angular/common/http';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { MatDialog } from '@angular/material/dialog';
import { EditDialogComponent } from '../../edit-dialog/edit-dialog.component';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { GetuserService } from '../../MyServices/Getuser/getuser.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    FormsModule,
    GridModule,
    ButtonsModule,
    InputsModule,
    CommonModule,
    HttpClientModule,
    HttpClientJsonpModule,
    DialogModule,
    DropDownsModule,
    MatButtonModule
  ],

  templateUrl: './home.component.html',
  providers: [EditService, HttpClient],
  styleUrl: './home.component.scss',
})
export class HomeComponent {

  response: any;

  editService: EditService;

  
  constructor(private dialog: MatDialog,private router: Router,private getuserService:GetuserService, editService:EditService) {
    this.editService = editService;
  }
  ngOnInit() {
    this.getuserService
    .authenticateUser()
    .then((res: any) => {
      this.response = res?.data
      console.log('Data from api', this.response);
    })
    .catch((err: any) => {
      console.log(err);
    });

  }
  sendMail(dataItem : any){
    console.log("Send mail dataIte,",dataItem)
  }
  editRow(dataItem: any) {
    const dialogRef = this.dialog.open(EditDialogComponent, {
      width: '400px',
      data: { ...dataItem }, 
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
    });

    dialogRef.componentInstance.updateData.subscribe((updatedData: any) => {
      this.updateData(updatedData)
    });
    
  }
  updateData(item:any){
    console.log(item)
    let id = item._id
    this.editService.authenticateUser(id,item.name, item.email,item.phone,item.state).then(()=>{
      console.log("Editing Successfull")

      // let newData = JSON.parse(JSON.stringify(mybooks))
    }).catch((err:any)=>{
      console.log(err)
    })
  }

  addNew(){
    this.router.navigate(['add']);
  }

  logout(){
    if(localStorage.getItem("authtoken")){
      localStorage.removeItem("authtoken")
      this.router.navigate([''])
    }
  }





//   const editBook = async (id:string,name: string, email: string, phone:string, state:string) => {


//     this.editService
//     .authenticateUser(this.name, this.email,this.phone,this.state)



//         console.log(response.data);
//         let newBooks = JSON.parse(JSON.stringify(mybooks))
//         for (let index = 0; index < newBooks.length; index++) {
//             const element = newBooks[index];
//             if (element._id === id) {
//                 newBooks[index].name = name;
//                 newBooks[index].category = category;
//                 newBooks[index].price = price;
//                 break;
//             }
//         }
//         console.log('Before dispatch:', newBooks);
//         dispatch(updateBooksAction(newBooks));
//         console.log('After dispatch:', mybookState?.products);


//     } catch (error) {
//         console.error('Error editing book:', error.message);
//     }
// };



}
