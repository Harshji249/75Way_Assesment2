import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AddUserService } from '../MyServices/adduser.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-adduser',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './adduser.component.html',
  styleUrl: './adduser.component.scss'
})
export class AdduserComponent {
name: any;
email: any;
password: any;
phone: any;
state: any;
  response: any;
  constructor(private router: Router,private addUserService:AddUserService ) {}
onSubmit() {
  console.log("Data",this.name, this.email,this.password)
  this.addUserService
    .authenticateUser(this.name, this.email,this.phone,this.state)
    .then((res: any) => {
      this.response = res.data
      this.name=""
      this.email=""
      this.phone=""
      this.state = ""
      console.log('Data from api', this.response);
      this.router.navigate(['home']);
    })
    .catch((err: any) => {
      console.log(err);
    });
}
}
