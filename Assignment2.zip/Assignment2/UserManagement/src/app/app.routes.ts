import { RouterModule, Routes } from '@angular/router';
import { OtpComponent } from './MyComponents/otp/otp.component';
import { HomeComponent } from './MyComponents/home/home.component';
import { AdduserComponent } from './adduser/adduser.component';
import { LoginComponent } from './MyComponents/login/login.component';
import { SignupComponent } from './MyComponents/signup/signup.component';

export const routes: Routes = [
    {
        component:SignupComponent,
        path:''
    },
    {
        component:LoginComponent,
        path:'login'
    }
    ,
     {
         component : OtpComponent,
         path: 'otp',

    },
    {
        component : HomeComponent,
        path: 'home'
    },

    {
        component : AdduserComponent,
        path: 'add'
    },

    
];

