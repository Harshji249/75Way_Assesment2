import { Injectable } from '@angular/core';
import axios from 'axios';

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {
  public baseURL = 'http://localhost:3000/api/auth/login'

  constructor() { }
  authenticateUser: any = async(email: string, password:string)=>{
    return await axios.post(this.baseURL ,{email:email,password:password})
  }
}
