import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { NgxOtpInputModule } from 'ngx-otp-input';
import { LoginServiceService } from '../../MyServices/Login/login.service';
import { SignupService } from '../../MyServices/Signup/signup.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, NgxOtpInputModule,RouterOutlet,RouterLink],
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.scss',
})
export class SignupComponent {

  name: string ='';
  email: string ='';
  password :string =''
  response : any;

  constructor(    private router: Router,private signupService:SignupService) {}


  onSubmit() {
    console.log("Data",this.name, this.email,this.password)
    this.signupService
      .authenticateUser(this.name, this.email,this.password)
      .then((res: any) => {
        this.response = res.data
        localStorage.setItem("authtoken", res.data.authToken)
        this.name=""
        this.email=""
        this.password=""
        console.log('Data from api', this.response);
        this.router.navigate(['otp']);
      })
      .catch((err: any) => {
        console.log(err);
      });
  }
  // }
}


