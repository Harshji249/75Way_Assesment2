import { Injectable } from '@angular/core';
import axios from 'axios';

@Injectable({
  providedIn: 'root'
})
export class GetuserService {
  public baseURL = 'http://localhost:3000/api/auth/getalldata'

  constructor() { }
  authenticateUser: any = async()=>{
    return await axios.get(this.baseURL)
  }
}