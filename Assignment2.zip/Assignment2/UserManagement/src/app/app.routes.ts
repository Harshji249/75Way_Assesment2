import { RouterModule, Routes } from '@angular/router';
import { OtpComponent } from './MyComponents/otp/otp.component';
import { HomeComponent } from './MyComponents/home/home.component';
import { AdduserComponent } from './adduser/adduser.component';

export const routes: Routes = [
     {
         component : OtpComponent,
         path: 'otp',

    },
    {
        component : HomeComponent,
        path: 'home'
    },

    {
        component : AdduserComponent,
        path: 'add'
    },

    
];

