import { Injectable } from '@angular/core';
import axios from 'axios';

@Injectable({
  providedIn: 'root'
})
export class EditService {
  public baseURL = 'http://localhost:3000/api/auth/updateuser/'

  constructor() { }
  authenticateUser: any = async(id:string,name: string, email: string, phone:string, state:string)=>{

    console.log("TEST ID FROM EDIT SERVICE",id)
    return await axios.put(this.baseURL+id,{name:name, email:email,phone:phone,state:state})
  }
}