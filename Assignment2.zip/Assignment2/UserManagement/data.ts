export const data = [
    {
        id:1,
        name:"Harsh Sharma",
        email:"harsh1234@gmail.com",
        phone : "9891027578",
        state:"Delhi",
        edit:'edit'
    },
    {
        id:2,
        name:"Raghav Sharma",
        email:"raghav1234@gmail.com",
        phone : "9891027578",
        state:"Haryana",
        edit:'edit'
    },
    {
        id:3,
        name:"Adil Ahmad",
        email:"adil1234@gmail.com",
        phone : "9891027578",
        state:"Jamshedpur",
        edit:'edit'
    },
    {
        id:4,
        name:"Aman Kumar",
        email:"aman1234@gmail.com",
        phone : "9891027578",
        state:"Jamshedpur",
        edit:'edit'
    },
    {
        id:5,
        name:"Amit Pandey",
        email:"amit1234@gmail.com",
        phone : "9891027578",
        state:"Delhi",
        edit:'edit'
    },
    {
        id:6,
        name:"Deepanshu",
        email:"deep1234@gmail.com",
        phone : "9891027578",
        state:"Punjab",
        edit:'edit'
    },
    {
        id:7,
        name:"Yuvraj Singh",
        email:"yuvraj1234@gmail.com",
        phone : "9891027578",
        state:"Chandigarh",
        edit:'edit'
    },
    {
        id:8,
        name:"Arpit Pandey",
        email:"arpit1234@gmail.com",
        phone : "9891027578",
        state:"Himachal",
        edit:'edit'
    },
    {
        id:9,
        name:"Abhay Singh",
        email:"abhay1234@gmail.com",
        phone : "9891027578",
        state:"Mohali",
        edit:'edit'
    },
    {
        id:10,
        name:"Daman",
        email:"daman1234@gmail.com",
        phone : "9891027578",
        state:"Haryana",
        edit:'edit'
    },

];
