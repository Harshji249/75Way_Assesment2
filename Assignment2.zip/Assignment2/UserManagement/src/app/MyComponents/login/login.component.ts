  import { Component } from '@angular/core';
  import { FormsModule } from '@angular/forms';
  import { Router, RouterLink, RouterOutlet } from '@angular/router';
  import { NgxOtpInputModule } from 'ngx-otp-input';
import { LoginServiceService } from '../../MyServices/Login/login.service';
 
  @Component({
    selector: 'app-login',
    standalone: true,
    imports: [FormsModule, NgxOtpInputModule,RouterOutlet,RouterLink],
    templateUrl: './login.component.html',
    styleUrl: './login.component.scss',
  })
  export class LoginComponent {

    email: string ='';
    password :string =''
    response : any;

    constructor(    private router: Router,private loginServiceService: LoginServiceService) {}


    onSubmit() {
      console.log("Data",this.email,this.password)
      this.loginServiceService
        .authenticateUser( this.email,this.password)
        .then((res: any) => {
          this.response = res.data
          localStorage.setItem("authtoken", res.data.authToken)
          this.email=""
          this.password=""
          console.log('Data from api', this.response);
          this.router.navigate(['home']);
        })
        .catch((err: any) => {
          console.log(err);
        });
    }
  }


