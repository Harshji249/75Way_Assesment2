const mongoose = require('mongoose')

const mongoURI = "mongodb+srv://hsharma75way:Harsh1234@cluster0.bfumnca.mongodb.net/UserManage?retryWrites=true&w=majority"

const connectToMongo = () => {
    mongoose.connect(mongoURI).then(() => {
        console.log("Connected to mongodb successfully");
      })
      .catch((err) => {
        console.log(err);
      });
}

module.exports = connectToMongo;