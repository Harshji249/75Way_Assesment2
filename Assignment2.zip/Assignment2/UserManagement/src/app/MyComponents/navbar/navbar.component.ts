import { Component } from '@angular/core';
import { Router } from '@angular/router';
import {MatSnackBar} from '@angular/material/snack-bar';
import {MatButtonModule} from '@angular/material/button';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [MatFormFieldModule, MatInputModule, MatButtonModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.scss'
})
export class NavbarComponent {
  constructor(private router: Router,private _snackBar: MatSnackBar){}
handleLogin(){
  if(localStorage.getItem("authtoken")){
    console.log("Already logged in")
    this.openSnackBar("Already logged in", "Close")
  }
  else{
    this.router.navigate(['login']);
  }
}

handleSignup(){
  if(localStorage.getItem("authtoken")){
    console.log("Already Signed in")
    this.openSnackBar("Already Signed in", "Close")
  }
  else{
    this.router.navigate(['']);
  }
}

handleDash(){
  if(localStorage.getItem("authtoken")){
    this.router.navigate(['home']);
  }
  else{
    this.router.navigate(['']);
    this.openSnackBar("Please Login First", "Close")
  }
}

openSnackBar(message: string, action: string) {
  this._snackBar.open(message, action);
}
}
