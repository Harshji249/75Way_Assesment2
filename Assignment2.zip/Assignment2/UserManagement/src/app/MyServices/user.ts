export class User {
    public id: number | undefined;
    public name = '';
    public email= '';
    public state ='';
    public phone = '';
}