// user.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private usersUrl = 'assets/users.json'; 

  constructor(private http: HttpClient) {}

  getUsers(): Observable<any[]> {
    return this.http.get<any[]>(this.usersUrl)
      .pipe(
        catchError(this.handleError<any[]>('getUsers', []))
      );
  }


  loginUser(username: string, password: string): Observable<boolean> {
    return this.getUsers().pipe(
      map(users => {
        const foundUser = users.find(user => user.username === username && user.password === password);
        return !!foundUser; 
      })
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error);
      return of(result as T);
    };
  }
}
